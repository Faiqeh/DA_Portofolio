Check out the minimal portfolio at https://chriskhanhtran.github.io/minimal-portfolio
